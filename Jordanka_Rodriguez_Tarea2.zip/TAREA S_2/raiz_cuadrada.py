# Asigna un valor numerico a una variable
numero = 56

# Calcula la raiz cuadrada del numero
raiz_cuadrada = numero ** 0.5

# Muestra el resultado
print("El numero es:", numero)
print("La raiz cuadrada es:", raiz_cuadrada)
