# Asignar valores decimales a dos variables
numero_decimal1 = 5.5
numero_decimal2 = 10.2

# Realizar operaciones matemáticas con decimales
suma = numero_decimal1 + numero_decimal2
resta = numero_decimal1 - numero_decimal2
multiplicacion = numero_decimal1 * numero_decimal2
division = numero_decimal1 / numero_decimal2

# Mostrar los resultados
print("Suma:", suma)
print("Resta:", resta)
print("Multiplicación:", multiplicacion)
print("División:", division)
