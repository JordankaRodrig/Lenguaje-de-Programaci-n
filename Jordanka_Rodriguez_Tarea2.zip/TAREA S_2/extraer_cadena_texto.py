# Definir una cadena de texto
cadena_texto = "Pirrimplines"

# Extraer la primera y ultima letra de la cadena
primera_letra = cadena_texto[0]
ultima_letra = cadena_texto[-1]

# Mostrar letras extraidas
print("Primera letra:", primera_letra)
print("Última letra:", ultima_letra)
