# Definir dos variables numericas
numero1 = 25
numero2 = 42

# Concatenar ambas variables para formar un nuevo numero
nuevo_numero = int(str(numero1) + str(numero2))

# Mostrar el resultado
print("El nuevo numero es:", nuevo_numero)