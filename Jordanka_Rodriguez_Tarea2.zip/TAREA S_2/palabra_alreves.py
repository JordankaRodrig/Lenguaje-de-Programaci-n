# Definir tres palabras
palabra1 = "Estrella"
palabra2 = "Jordanka"
palabra3 = "Nicaragua"

# Mostrar las palabras al reves
print("Palabra 1 al reves:", palabra1[::-1])
print("Palabra 2 al reves:", palabra2[::-1])
print("Palabra 3 al reves:", palabra3[::-1])
