# Elige un numero de dos digitos
numero = 56

# Separa los digitos
digito1 = numero // 10
digito2 = numero % 10

# Suma los digitos  individualmente
suma_digitos = digito1 + digito2

# Mostrar el resultado
print("El numero es:", numero)
print("La suma de los digitos es:", suma_digitos)
