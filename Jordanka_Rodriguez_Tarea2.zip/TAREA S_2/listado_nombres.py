# Crear una lista con nombres de personas
nombres = ["Diego", "Marina", "Zoe", "Gianluca", "Alejandra"]

# Imprimir el tercer nombre de la lista
tercer_nombre = nombres[2]
print("El tercer nombre de la lista es:", tercer_nombre)
