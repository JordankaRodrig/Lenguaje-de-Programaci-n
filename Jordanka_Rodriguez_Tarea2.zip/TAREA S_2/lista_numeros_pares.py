# Definir una lista con los primeros cinco números pares
numeros_pares = [2, 4, 6, 8, 10]

# imprimir lista
print("La lista de los primeros cinco números pares es:", numeros_pares)
