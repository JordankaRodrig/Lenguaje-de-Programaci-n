# Escoger numero
numero = 34

# Calcular el cuadrado del numero
cuadrado = numero ** 2

# Mostrar el resultado
print("El cuadrado de", numero, "es:", cuadrado)
