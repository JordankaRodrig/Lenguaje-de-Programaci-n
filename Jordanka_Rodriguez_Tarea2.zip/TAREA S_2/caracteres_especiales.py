# Define una cadena de texto con un caracter especial
caracter_especial = "Hola, este es un mensale especial, Mi nombres es Jordanka. "

# Imprime la cadena
print(caracter_especial)
